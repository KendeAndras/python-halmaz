file1=open("adatok4.txt","r")
coll=[]

i=file1.readline()[:-1]

while i!="":
    coll.append(i.split())
    i=file1.readline()[:-1]
file1.close()

print(coll)

for i in coll:
    if i[1]=='1': print(i[0])

dictionary=dict(coll)
print(dictionary)

group=[]
for i in dictionary:
    if dictionary[i]=='1': group.append(i)
print(group)